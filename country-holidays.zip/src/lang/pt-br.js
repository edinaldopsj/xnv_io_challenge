export const LANG = {
  COUNTRY_SELECTOR: 'Selecione o país',
  COUNTRY_SELECTOR_SUB: 'Para visualizar seus feriados',
  SELECT_COUNTRY: 'Selecione o seu país',
}
